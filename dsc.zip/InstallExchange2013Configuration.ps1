

Configuration Main
{

	Param ( [PSCredential]$AdminCredential, 
			[string]$DomainName, 
			[string]$domainNameNetbios, 
			[string]$ExchangeOrgName, 
			[string]$ExchangeProductKey,
			[string]$ExchangeFQDN,
			[string]$SourcePathSignInAssistant,
			[string]$TargetPathSignInAssistant,
			[string]$GUIDSignInAssistant,
			[string]$SourcePathAADPS,
			[string]$TargetPathAADPS,
			[string]$PublicZoneNS1,
			[string]$PublicZoneNS2,
			[string]$PublicZoneNS3,
			[string]$PublicZoneNS4,
			[Int]$RetryCount=20, 
			[Int]$RetryIntervalSec=30 )

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xDisk, xNetworking, xPendingReboot, cDisk, xExchange, xSystemSecurity

    [PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${domainNameNetbios}\$($AdminCredential.UserName)", $AdminCredential.Password)

	Node localhost
	{

		[string]$DownloadsFolder = "f:\Downloads"
		[string]$ConfigLog = "f:\LabConfig.txt"

		
		LocalConfigurationManager            
		{            
			ActionAfterReboot = 'ContinueConfiguration'            
			ConfigurationMode = 'ApplyOnly'            
			RebootNodeIfNeeded = $true            
		} 
		

		# Desktop Experience Restart Pending
		Script DesktopExperiencePending
		{
			TestScript = {
				if ((Get-WindowsFeature Desktop-Experience).InstallState -eq "InstallPending") {$false} Else {$true}
			}
			SetScript = {
				Start-Sleep -Seconds 180
			}
			GetScript = {@{Result = "DesktopExperiencePending"}}
		}	


		xWaitforDisk Disk2
		{
			DiskNumber = 2
			RetryIntervalSec =$RetryIntervalSec
			RetryCount = $RetryCount
		}

		cDiskNoRestart ADDataDisk
		{
			DiskNumber = 2
			DriveLetter = "F"
		}

        xIEEsc DisableIEEsc
        {
            IsEnabled = $false
            UserRole = "Administrators"
        }

        xFirewall FWFileShare1
        {
            Name      = "File and Printer Sharing (NB-Datagram-In)"
            Ensure    = "Present"
            Enabled   = "True"
        }

        xFirewall FWFileShare2
        {
            Name      = "File and Printer Sharing (NB-Name-In)"
            Ensure    = "Present"
            Enabled   = "True"
        }

        xFirewall FWFileShare3
        {
            Name      = "File and Printer Sharing (NB-Session-In)"
            Ensure    = "Present"
            Enabled   = "True"
        }

        xFirewall FWFileShare4
        {
            Name      = "File and Printer Sharing (SMB-In)"
            Ensure    = "Present"
            Enabled   = "True"
        }



		# =================================
		# Desktop Experience requires multple reboots and careful handling
		<#

		Script InstallInkSupport
		{
			TestScript = {
				if ((Get-WindowsFeature InkAndHandwritingServices).InstallState -like "Install*") {$true} Else {$false}
			}
			SetScript = {
				Add-WindowsFeature -Name InkAndHandwritingServices
				$global:DSCMachineStatus = 1
			}
			GetScript = {@{Result = "InstallInkSupport"}}
		}

		xPendingReboot RebootInstallInkSupport
		{
			Name      = "AfterInstallInkSupport"
			DependsOn  = '[Script]InstallInkSupport'
		}

		Script InstallServerMediaFoundation
		{
			TestScript = {
				if ((Get-WindowsFeature Server-Media-Foundation).InstallState -like "Install*") {$true} Else {$false}
			}
			SetScript = {
				Add-WindowsFeature -Name Server-Media-Foundation
				$global:DSCMachineStatus = 1
			}
			GetScript = {@{Result = "InstallServerMediaFoundation"}}
			DependsOn  = '[xPendingReboot]RebootInstallInkSupport'
		}

		xPendingReboot RebootInstallServerMediaFoundation
		{
			Name      = "AfterInstallServerMediaFoundation"
			DependsOn  = '[Script]InstallServerMediaFoundation'
		}

		Script InstallDesktopExperience
		{
			TestScript = {
				if ((Get-WindowsFeature desktop-experience).InstallState -like "Install*") {$true} Else {$false}
			}
			SetScript = {
				Add-WindowsFeature -Name desktop-experience
				Set-Service -name TrustedInstaller -startupType Disabled
				"Added Desktop Experience" | Set-Content f:\desktopexperience.txt
				$global:DSCMachineStatus = 1
			}
			GetScript = {@{Result = "InstallDesktopExperience"}}
			DependsOn  = '[xPendingReboot]RebootInstallServerMediaFoundation'
		}

		xPendingReboot RebootInstallDesktopExperience
		{
			Name      = "AfterDesktopExperience"
			DependsOn  = '[Script]InstallDesktopExperience'
		}

        Script AfterInstallDesktopExperience
        {
			TestScript = {
				if (Test-Path f:\desktopexperience.txt) {$false} else {$true}
			}
			SetScript = {
				Remove-Item f:\desktopexperience.txt -Force
				Set-Service -name TrustedInstaller -startupType Manual
                $global:DSCMachineStatus = 1
			}
			GetScript = {@{Result = "AfterInstallDesktopExperience"}}
            DependsOn  = '[xPendingReboot]RebootInstallDesktopExperience'            
        }

   		xPendingReboot RebootAfterInstallDesktopExperience
		{
			Name      = "AfterInstallDesktopExperience"
			DependsOn  = '[Script]InstallDesktopExperience'
		}

		Script InstallASHTTPActivation
		{
			TestScript = {
				if ((Get-WindowsFeature AS-HTTP-Activation).InstallState -like "Install*") {$true} Else {$false}
			}
			SetScript = {
				Add-WindowsFeature -Name AS-HTTP-Activation
				$global:DSCMachineStatus = 1
			}
			GetScript = {@{Result = "InstallASHTTPActivation"}}
			DependsOn  = '[xPendingReboot]RebootAfterInstallDesktopExperience'
		}


		# Done with Desktop experience
		# =================================

		#>

        WindowsFeature DesktopExperience
		{
			Ensure = "Present" 
			Name = "Desktop-Experience"
		}

        xPendingReboot AfterDesktopExperience
		{
			Name      = "AfterDesktopExperience"
			DependsOn  = '[WindowsFeature]DesktopExperience'
		}

		WindowsFeature ASHTTPActivation
		{
			Ensure = "Present" 
			Name = "AS-HTTP-Activation"
		}

		WindowsFeature NETFramework45Features
		{
			Ensure = "Present" 
			Name = "NET-Framework-45-Features"
		}

		WindowsFeature RPCoverHTTPproxy
		{
			Ensure = "Present" 
			Name = "RPC-over-HTTP-proxy"
		}

		WindowsFeature RSATClustering
		{
			Ensure = "Present" 
			Name = "RSAT-Clustering"
		}

		WindowsFeature RSATADDS
		{
			Ensure = "Present" 
			Name = "RSAT-ADDS"
		}

		WindowsFeature RSATClusteringCmdInterface
		{
			Ensure = "Present" 
			Name = "RSAT-Clustering-CmdInterface"
		}

		WindowsFeature RSATClusteringMgmt
		{
			Ensure = "Present" 
			Name = "RSAT-Clustering-Mgmt"
		}

		WindowsFeature RSATClusteringPowerShell
		{
			Ensure = "Present" 
			Name = "RSAT-Clustering-PowerShell"
		}

		WindowsFeature WebMgmtConsole
		{
			Ensure = "Present" 
			Name = "Web-Mgmt-Console"
		}

		WindowsFeature WASProcessModel
		{
			Ensure = "Present" 
			Name = "WAS-Process-Model"
		}

		WindowsFeature WebAspNet45
		{
			Ensure = "Present" 
			Name = "Web-Asp-Net45"
		}

		WindowsFeature WebBasicAuth
		{
			Ensure = "Present" 
			Name = "Web-Basic-Auth"
		}

		WindowsFeature WebClientAuth
		{
			Ensure = "Present" 
			Name = "Web-Client-Auth"
		}

		WindowsFeature WebDigestAuth
		{
			Ensure = "Present" 
			Name = "Web-Digest-Auth"
		}

		WindowsFeature WebDirBrowsing
		{
			Ensure = "Present" 
			Name = "Web-Dir-Browsing"
		}

		WindowsFeature WebDynCompression
		{
			Ensure = "Present" 
			Name = "Web-Dyn-Compression"
		}
	  
		WindowsFeature WebHttpErrors
		{
			Ensure = "Present" 
			Name = "Web-Http-Errors"
		}

		WindowsFeature WebHttpLogging
		{
			Ensure = "Present" 
			Name = "Web-Http-Logging"
		}

		WindowsFeature WebHttpRedirect
		{
			Ensure = "Present" 
			Name = "Web-Http-Redirect"
		}

		WindowsFeature WebHttpTracing
		{
			Ensure = "Present" 
			Name = "Web-Http-Tracing"
		}

		WindowsFeature WebISAPIExt
		{
			Ensure = "Present" 
			Name = "Web-ISAPI-Ext"
		}

		WindowsFeature WebISAPIFilter
		{
			Ensure = "Present" 
			Name = "Web-ISAPI-Filter"
		}

		WindowsFeature WebLgcyMgmtConsole
		{
			Ensure = "Present" 
			Name = "Web-Lgcy-Mgmt-Console"
		}

		WindowsFeature WebMetabase
		{
			Ensure = "Present" 
			Name = "Web-Metabase"
		}

		WindowsFeature WebMgmtService
		{
			Ensure = "Present" 
			Name = "Web-Mgmt-Service"
		}

		WindowsFeature WebNetExt45
		{
			Ensure = "Present" 
			Name = "Web-Net-Ext45"
		}

		WindowsFeature WebRequestMonitor
		{
			Ensure = "Present" 
			Name = "Web-Request-Monitor"
		}

		WindowsFeature WebServer
		{
			Ensure = "Present" 
			Name = "Web-Server"
		}

		WindowsFeature WebStatCompression
		{
			Ensure = "Present" 
			Name = "Web-Stat-Compression"
		}

		WindowsFeature WebStaticContent
		{
			Ensure = "Present" 
			Name = "Web-Static-Content"
		}
		
		WindowsFeature WebWindowsAuth
		{
			Ensure = "Present" 
			Name = "Web-Windows-Auth"
		} 

		WindowsFeature WebWMI
		{
			Ensure = "Present" 
			Name = "Web-WMI"
		}

		WindowsFeature WindowsIdentityFoundation
		{
			Ensure = "Present" 
			Name = "Windows-Identity-Foundation"
		}

		WindowsFeature TelnetClient
		{
			Ensure = "Present" 
			Name = "Telnet-Client"
		}
	
		xPendingReboot AfterFeaturesInstall
		{
			Name      = "AfterFeaturesInstall"
		}

		File CreateDownloadFolder
		{
			DestinationPath = "f:\Downloads"
			Ensure = "Present"
			Type = "Directory"
		}

		Script DownloadExchange2013CU16
		{
			TestScript = {
				Test-Path "F:\downloads\Exchange2013-x64-cu16.exe"
			}
			SetScript ={
				$source = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=54931"
				$dest = "F:\downloads\Exchange2013-x64-cu16.exe"
                $webclient = new-object System.Net.WebClient
                $webclient.DownloadFile($source, $dest)
			}
			GetScript = {@{Result = "DownloadExchange2013CU16"}}
			DependsOn = "[File]CreateDownloadFolder"
		}

		Script UnpackExchange
		{
			TestScript = {
				Test-Path "f:downloads\Exchange2013Source\setup.exe"
			}
			SetScript ={
				$FilePath = "F:\downloads\Exchange2013-x64-cu16.exe"
				$ExtractLocation = "f:\downloads\Exchange2013Source\"
				$appArgs = '/quiet /extract:"' + $ExtractLocation + '"'
				Start-Process $FilePath $appArgs -PassThru | Wait-Process
			}
			GetScript = {@{Result = "UnpackExchange"}}
			DependsOn = "[Script]DownloadExchange2013CU16"
		}

		<#
		Package OCRuntime {
            Name = "Runtime Exchange"
            Path = "F:\downloads\UcmaRuntimeSetup.exe"
            Productid = "ED98ABF5-B6BF-47ED-92AB-1CDCAB964447"
            Arguments = "/passive /norestart"
            Ensure = "Present"
            returncode = 0
        }
		#>

		Script DownloadUnifiedCommunicationsManagedAPI4Runtime
		{
			TestScript = {
				Test-Path "F:\downloads\UcmaRuntimeSetup.exe"
			}
			SetScript ={
				$source = "https://download.microsoft.com/download/2/C/4/2C47A5C1-A1F3-4843-B9FE-84C0032C61EC/UcmaRuntimeSetup.exe"
				$dest = "F:\downloads\UcmaRuntimeSetup.exe"
				Invoke-WebRequest $source -OutFile $dest
			}
			GetScript = {@{Result = "DownloadUnifiedCommunicationsManagedAPI4Runtime"}}
			DependsOn = "[File]CreateDownloadFolder","[Script]UnpackExchange"
		}
		

		Script InstallUnifiedCommunicationsManagedAPI4Runtime
		{

			TestScript = {
				if (Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\UCMA4" -erroraction SilentlyContinue) {$true} Else {$false}
			}
			SetScript ={
				$FilePath = "F:\downloads\UcmaRuntimeSetup.exe"
				$appArgs = "/quiet /norestart"
				Start-Process $FilePath $appArgs -PassThru | Wait-Process
			}
			GetScript = {@{Result = "InstallUnifiedCommunicationsManagedAPI4Runtime"}}
			DependsOn = "[Script]DownloadUnifiedCommunicationsManagedAPI4Runtime"

		}

		Script DownloadSignInAssistant
		{
			TestScript = {
				Test-Path ($using:DownloadsFolder + "\" + $using:TargetPathSignInAssistant)
			}
			SetScript ={
                Invoke-WebRequest $Using:SourcePathSignInAssistant -OutFile ($using:DownloadsFolder + "\" + $using:TargetPathSignInAssistant)
			}
			GetScript = {@{Result = "DownloadSignInAssistant"}}
			DependsOn = "[File]CreateDownloadFolder"
		}

		Package InstallSignInAssistant {
            Name = "Microsoft Online Services Sign-in Assistant"
            Path = ($DownloadsFolder + "\" + $TargetPathSignInAssistant)
            Productid = $GUIDSignInAssistant
            Arguments = "/passive /norestart"
            Ensure = "Present"
            returncode = 0
			DependsOn = "[script]DownloadSignInAssistant"
        }

		Script DownloadAADPowerShell
		{
			TestScript = {
				Test-Path ($using:DownloadsFolder + "\" + $using:TargetPathAADPS)
			}
			SetScript ={
                Invoke-WebRequest $Using:SourcePathAADPS -OutFile ($using:DownloadsFolder + "\" + $using:TargetPathAADPS)
			}
			GetScript = {@{Result = "DownloadAADPowerShell"}}
			DependsOn = "[File]CreateDownloadFolder"
		}

		Package InstallAADPowerShell {
            Name = "Windows Azure Active Directory Module for Windows PowerShell"
            Path = ($DownloadsFolder + "\" + $TargetPathAADPS)
            Productid = "43CC9C53-A217-4850-B5B2-8C347920E500"
            Arguments = "/passive /norestart"
            Ensure = "Present"
            returncode = 0
			DependsOn = "[script]DownloadAADPowerShell"
        }

		xPendingReboot BeforeExchangeInstall
		{
			Name      = "BeforeExchangeInstall"
			DependsOn  = '[Script]InstallUnifiedCommunicationsManagedAPI4Runtime','[script]UnpackExchange'
		}

		xExchInstall InstallExchange
		{
			Path       = "f:\downloads\Exchange2013Source\setup.exe"
			Arguments  = "/mode:Install /role:Mailbox,ClientAccess /Iacceptexchangeserverlicenseterms /OrganizationName:$ExchangeOrgName"
			Credential = $DomainCreds
			DependsOn  = '[xPendingReboot]BeforeExchangeInstall'
		}
		
		Service winrmautomatic
		{
			Name = "winrm"
			StartupType = 'Automatic'
			DependsOn = '[xExchInstall]InstallExchange'
		}

		xPendingReboot AfterExchangeInstall
		{
			Name      = "AfterExchangeInstall"
			DependsOn = '[xExchInstall]InstallExchange'
		}

		xExchExchangeServer EXServer 
		{ 
			Identity            = ($env:COMPUTERNAME)
			Credential          = $DomainCreds
			ProductKey          = $ExchangeProductKey
			AllowServiceRestart = $true
			DependsOn           = '[xPendingReboot]AfterExchangeInstall'
		}

		xExchWebServicesVirtualDirectory EWSVdir
        {
            Identity            = "$($env:COMPUTERNAME)\EWS (Default Web Site)"
            Credential          = $DomainCreds
            ExternalUrl         = "https://$($ExchangeFQDN)/ews/exchange.asmx"
            AllowServiceRestart = $true
			DependsOn           = '[xPendingReboot]AfterExchangeInstall'
        }

		xExchOutlookAnywhere OAVdir
        {
            Identity                           = "$($env:COMPUTERNAME)\Rpc (Default Web Site)"
            Credential                         = $DomainCreds
            ExternalHostName                   = $ExchangeFQDN
			ExternalClientsRequireSSL          = $true
			ExternalClientAuthenticationMethod = 'Negotiate'
            AllowServiceRestart                = $true
			DependsOn                          = '[xPendingReboot]AfterExchangeInstall'
        }

		Script UpdateECPURL
		{
			TestScript = {
				$Shell = New-Object -ComObject ("WScript.Shell")
				$Shurtcut = $Shell.CreateShortcut("$env:ALLUSERSPROFILE\Microsoft\Windows\Start Menu\Programs\Microsoft Exchange Server 2013\Exchange Administrative Center.url")
				$Shurtcut.TargetPath.Contains($using:ExchangeFQDN)
			}
			SetScript ={
				$Shell = New-Object -ComObject ("WScript.Shell")
				$Shurtcut = $Shell.CreateShortcut("$env:ALLUSERSPROFILE\Microsoft\Windows\Start Menu\Programs\Microsoft Exchange Server 2013\Exchange Administrative Center.url")
				$Shurtcut.TargetPath = $Shurtcut.TargetPath.Replace("localhost", $using:ExchangeFQDN)
				$Shurtcut.Save()                
			}
			GetScript = {@{Result = "UpdateECPURL"}}
			DependsOn = "[xExchInstall]InstallExchange"			

		}

		Script ConfigOutput
		{
			TestScript = {
				Test-Path ($using:ConfigLog)
			}
			SetScript ={
                
				Add-Content -Path $using:ConfigLog  -Value "Exchange Server Internal FQDN: $using:ExchangeFQDN"
				Add-Content -Path $using:ConfigLog  -Value "Public Zone Name Server 1: $using:PublicZoneNS1"
				Add-Content -Path $using:ConfigLog  -Value "Public Zone Name Server 2: $using:PublicZoneNS2"
				Add-Content -Path $using:ConfigLog  -Value "Public Zone Name Server 3: $using:PublicZoneNS3"
				Add-Content -Path $using:ConfigLog  -Value "Public Zone Name Server 4: $using:PublicZoneNS4"

			}
			GetScript = {@{Result = "DownloadAADPowerShell"}}
			DependsOn = "[File]CreateDownloadFolder"

		}

	}

}